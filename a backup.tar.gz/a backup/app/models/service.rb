class Service < ApplicationRecord

	has_many :products

end
